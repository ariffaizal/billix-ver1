

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body px-4 py-4-5">
                    <div class="mb-2">
                        <?php if(!empty($shift)): ?>
                            <button class="btn btn-primary" type="button" id="btnSelectOrder">
                                <i class="bi bi-check2-square"></i> Select Order
                            </button>
                        <?php endif; ?>
                        <?php if(auth()->user()->role == 'owner'): ?>
                            <a href="<?php echo e(route('orders')); ?>" class="btn btn-outline-primary">
                                <i class="bi bi-arrow-left"></i>
                                Orders List
                            </a>
                            <a href="<?php echo e(route('orders.history')); ?>" class="btn btn-outline-primary">
                                <i class="bi bi-clock-history"></i>
                                Orders History
                            </a>
                        <?php endif; ?>
                    </div>
                    <table class="table table-hover" id="tabelData">
                        <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Time</th>
                                <th>Bill To</th>
                                <th>Subtotal</th>
                                <th>Discount</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/orders/refund.js']); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postabel-dev\resources\views/orders/refund.blade.php ENDPATH**/ ?>