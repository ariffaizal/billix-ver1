

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-row justify-content-between mb-3">
                        <div>
                            <h4>Order ID #<?php echo e($data['order']->id_order); ?></h4>
                            <p>Status : <?php echo $data['status']; ?></span></p>

                        </div>
                        <div class="hstack gap-2 align-items-start">
                            <a href="<?php echo e(route('orders')); ?>" class="btn btn-outline-primary"><i class="bi bi-arrow-left"></i>
                                Order List</a>
                        </div>
                    </div>
                    <table class="table" id="tableItems">
                        <thead>
                            <th>Items</th>
                            <th>Package / Qty</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Amount</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i['items']); ?>

                                        <?php if($data['order']->order_status == 3 && $i['is_table'] == 1): ?>
                                            <button class="btn btn-sm btn-outline-info btnTransfer"
                                                data-id="<?php echo e($i['id_order_item']); ?>">
                                                <i class="bi bi-arrow-left-right"></i> Transfer
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($i['qty']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($i['price'], 0, ',', '.')); ?></td>
                                    <td class="text-end"><?php echo e(number_format($i['amount'], 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <table class="table">
                            <tr>
                                <td>Bill To</td>
                                <td class="text-end">
                                    <?php echo e($data['order']->bill_name); ?>

                                </td>
                            </tr>
                            
                            <tr>
                                <td>Subtotal</td>
                                <td class="text-end">
                                    <?php echo e(number_format($data['order']->price_subtotal, 0, ',', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>Discount</td>
                                <td class="text-end">
                                    <?php echo e(number_format($data['order']->price_discount, 0, ',', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>VAT</td>
                                <td class="text-end">
                                    <?php echo e(number_format($data['order']->price_vat, 0, ',', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="font-extrabold">Total Refund</td>
                                <td class="font-extrabold text-end">
                                    <?php echo e(number_format($data['order']->price_total, 0, ',', '.')); ?>

                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="mb-3">
                        <a href="<?php echo e(route('orders.print', ['id_order' => $data['order']->id_order])); ?>" target="_blank"
                            class="btn btn-lg btn-block btn-primary">
                            <i class="bi bi-printer"></i> Print Receipt</a>
                    </div>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/billiar89ciamis/public_html/resources/views/orders/view_refund.blade.php ENDPATH**/ ?>