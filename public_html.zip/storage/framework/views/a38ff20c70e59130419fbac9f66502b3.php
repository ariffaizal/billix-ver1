

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <th>ID</th>
                            <th>Opened by</th>
                            <th>Opening time</th>
                            <th>Closing time</th>
                            <th>Expected cash amount</th>
                            <th>Actual cash amount</th>
                            <th>Difference</th>
                            <th>Action</th>
                        </thead>
                        <tbody>

                            <tr>
                                <td><?php echo e($data['shift']->id_user_shift); ?></td>
                                <td><?php echo e($data['user']->name); ?></td>
                                <td><?php echo e($data['shift']->shift_start); ?></td>
                                <td><?php echo e($data['shift']->shift_end); ?></td>
                                <td><?php echo e(number_format($data['expected'], 0, ',', '.')); ?></td>
                                <td><?php echo e(number_format($data['shift']->cash_actual, 0, ',', '.')); ?></td>
                                <td><?php echo e(number_format($data['diff'], 0, ',', '.')); ?></td>
                                <td>
                                    <a href="<?php echo e(url('reports/byshift/print?id=' . $data['shift']->id_user_shift)); ?>"
                                        target="_blank" class="btn btn-sm btn-outline-primary" title="Print this report"><i
                                            class="bi bi-printer"></i> Print</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/billiar89/public_html/resources/views/reports/close_shift.blade.php ENDPATH**/ ?>