<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body px-4 py-4-5">
                    
                    <table class="table table-hover" id="tabelData">
                        <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Time</th>
                                <th>Bill To</th>
                                <th>Subtotal</th>
                                <th>Discount</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i->id_order); ?></td>
                                    <td><?php echo e($i->order_time); ?></td>
                                    <td class="text-end"><?php echo e($i->bill_name); ?></td>
                                    <td class="text-end"><?php echo e($i->price_subtotal); ?></td>
                                    <td class="text-end"><?php echo e($i->price_discount); ?></td>
                                    <td class="text-end"><?php echo e($i->price_total); ?></td>
                                    <td class="text-end">
                                        <a href="<?php echo e(route('orders.pay', ['id_order' => $i->id_order])); ?>"
                                            class="btn btn-sm btn-info" id="btnDetail">Pay</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postabel-dev\resources\views/mainapp/pending.blade.php ENDPATH**/ ?>