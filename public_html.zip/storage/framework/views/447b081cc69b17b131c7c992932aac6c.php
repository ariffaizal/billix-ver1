

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body px-4 py-4-5">
                    <div class="mb-3">
                        <button type="button" class="btn btn-primary" id="btnAdd">
                            <i class="bi bi-plus-lg"></i>
                            Tambah Paket
                        </button>
                    </div>
                    <table class="table table-hover" id="tabelData">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Paket</th>
                                <th>Time Limit</th>
                                <th>Harga</th>
                                <th>action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalAdd" aria-labelledby="modalAddLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalAddLabel">Form Board</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="#" id="formAdd">
                        <div class="mb-3">
                            <label for="paket" class="form-label">Paket*</label>
                            <input type="text" name="paket" class="form-control" id="paket" required>
                        </div>
                        <div class="mb-3">
                            <label for="time_limit" class="form-label">Time limit*</label>
                            <input type="text" name="time_limit" class="form-control" id="time_limit" required
                                value="00:00:00">
                            <span>Jam:Menit:Detik, contoh 01:30:00</span>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga*</label>
                            <input type="number" name="harga" class="form-control" id="harga" required>
                        </div>
                        <input type="hidden" name="id" id="id">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary" form="formAdd" id="submitAdd">Simpan</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/mainapp/paket.js']); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postabel-dev\resources\views/prices/price_package.blade.php ENDPATH**/ ?>