

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body px-4 py-4-5">
                    <div class="mb-3">
                        <form action="<?php echo e(route('main.order.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary" id="btnOrderNew">
                                <i class="bi bi-plus-lg"></i>
                                Buat Order Baru
                            </button>
                        </form>
                    </div>
                    <span>Data Order hari ini (<?php echo e(date('d-m-Y')); ?>)</span>
                    <table class="table table-lg table-hover" id="tabelData">
                        <thead>
                            <tr>
                                <th>ID#</th>
                                <th>Waktu</th>
                                <th>Nama Billing</th>
                                <th>Sub Total</th>
                                <th>Diskon</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>By</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/mainapp/order.js']); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\postabel-dev\resources\views/mainapp/order.blade.php ENDPATH**/ ?>