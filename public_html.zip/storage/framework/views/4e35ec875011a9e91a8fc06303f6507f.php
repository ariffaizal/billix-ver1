<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('script_tag'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/ext/choices.js/choices.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-row justify-content-between mb-3">
                        <div>
                            <h4>Order ID #<?php echo e($data['order']->id_order); ?></h4>
                            <p>Status : <?php echo $data['status']; ?></span></p>

                        </div>
                        <div class="hstack gap-2 align-items-start">
                            <?php if($data['order']->order_type != 'open_bill'): ?>
                                <form action="<?php echo e(route('orders.statustodraft')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id_order" value="<?php echo e($data['order']->id_order); ?>">
                                    <button type="submit" class="btn btn-outline-primary">
                                        <i class="bi bi-pencil-square"></i>
                                        Edit Items</button>
                                </form>
                            <?php endif; ?>
                            <a href="<?php echo e(route('orders')); ?>" class="btn btn-outline-primary"><i class="bi bi-arrow-left"></i>
                                Order List</a>
                        </div>
                    </div>
                    <table class="table" id="tableItems">
                        <thead>
                            <th>Items</th>
                            <th>Package / Qty</th>
                            <th class="text-end">Price</th>
                            <th class="text-end">Amount</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i['items']); ?></td>
                                    <td><?php echo e($i['qty']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($i['price'], 0, ',', '.')); ?></td>
                                    <td class="text-end"><?php echo e(number_format($i['amount'], 0, ',', '.')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="#" id="formBilling">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="bill_name" class="form-label">Bill To*</label>
                            <input type="text" class="form-control" name="bill_name" id="bill_name" required
                                value="<?php echo e($data['order']->bill_name); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="member" class="form-label">Member</label>
                            <select name="member" id="member" class="form-select">
                                <option value="">None</option>
                                <?php $__currentLoopData = $data['member']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $selected = $member->id_member == $data['order']->id_member ? 'selected' : '';
                                    ?>
                                    <option value="<?php echo e($member->id_member); ?>" <?php echo e($selected); ?>>
                                        <?php echo e($member->member_name); ?>

                                        [<?php echo e($member->member_no); ?>]</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="payment_method" class="form-label">Payment Method*</label>
                            <select name="payment_method" id="payment_method" class="form-select" required>
                                <option value="Cash">Cash</option>
                                <option value="Transfer">Transfer</option>
                                <option value="QRIS">QRIS</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <table class="table">
                                <tr>
                                    <td>Subtotal</td>
                                    <td class="text-end">
                                        <input type="hidden" name="subtotal" id="subtotal"
                                            value="<?php echo e($data['order']->price_subtotal); ?>">
                                        <?php echo e(number_format($data['order']->price_subtotal, 0, ',', '.')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Discount</td>
                                    <td class="text-end">
                                        <select name="discount" id="discount" class="form-select">
                                            <option value="0" selected>None</option>
                                            <?php $__currentLoopData = $data['discount']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($disc->price); ?>"><?php echo e($disc->name); ?> |
                                                    <?php echo e($disc->price); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>VAT</td>
                                    <td class="text-end">
                                        <?php
                                            $vat = $data['order']->price_subtotal * ($data['tax']->rate / 100);
                                            $tmpTotal = $data['order']->price_total + $vat;
                                        ?>
                                        <input type="hidden" name="tax_rate" id="tax_rate"
                                            value="<?php echo e($data['tax']->rate); ?>">
                                        <input type="hidden" name="vat" id="vat" value="<?php echo e($vat); ?>">
                                        <span id="showVAT">
                                            <?php echo e(number_format($vat, 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-extrabold">Total</td>
                                    <td class="font-extrabold text-end">
                                        <input type="hidden" name="total" id="total" value="<?php echo e($tmpTotal); ?>">
                                        <span id="showTotal">
                                            <?php echo e(number_format($tmpTotal, 0, ',', '.')); ?>

                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Cash</td>
                                    <td class="text-end">
                                        <input type="number" class="form-control text-end" name="cash" id="cashTendered"
                                            required>
                                        <span id="showCash"></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Change</td>
                                    <td class="text-end">
                                        <input type="hidden" name="change" id="change" required>
                                        <span id="changeText"></span>
                                    </td>
                                </tr>
                            </table>

                        </div>
                        <div class="mb-3">
                            <input type="hidden" name="id_order" value="<?php echo e($data['order']->id_order); ?>">
                            <button type="submit" class="btn btn-lg btn-block btn-success" id="submitFormBilling">
                                <i class="bi bi-cash-stack"></i> Confirm Payment</button>
                        </div>
                        <?php if($data['order']->order_type != 'open_bill'): ?>
                            <div>
                                <button type="button" class="btn btn-lg btn-block btn-outline-danger" id="cancelOrder">
                                    <i class="bi bi-x-circle"></i> Cancel </button>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/ext/choices.js/choices.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/orders/payment.js']); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/billiar89/public_html/resources/views/orders/payment.blade.php ENDPATH**/ ?>