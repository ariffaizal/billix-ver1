<nav class="main-navbar">
    <div class="container">
        <ul>
            <li class="menu-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class='menu-link'>
                    <span><i class="bi bi-speedometer2"></i> Dashboard</span>
                </a>
            </li>
            <li class="menu-item <?php echo e(request()->routeIs('orders.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('orders')); ?>" class='menu-link'>
                    <span><i class="bi bi-cart-plus"></i> Order Lists</span>
                </a>
            </li>
            <?php if(auth()->user()->role == 'owner'): ?>
                <li class="menu-item has-sub <?php echo e(request()->routeIs('prices.*') ? 'active' : ''); ?>">
                    <a href="#" class="menu-link">
                        <span><i class="bi bi-coin"></i> Packages & Prices</span>
                    </a>
                    <div class="submenu ">
                        <div class="submenu-group-wrapper">
                            <ul class="submenu-group">
                                <li class="submenu-item <?php echo e(request()->routeIs('prices.package') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('prices.package')); ?>">Packages</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('prices.openbill') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('prices.openbill')); ?>">Open Billing</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('prices.discount') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('prices.discount')); ?>">Discount</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="menu-item has-sub <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
                    <a href="#" class="menu-link">
                        <span><i class="bi bi-sliders"></i> Administration</span>
                    </a>
                    <div class="submenu ">
                        <div class="submenu-group-wrapper">
                            <ul class="submenu-group">
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.member') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.member')); ?>">Members</a>
                                </li>
                                <li
                                    class="submenu-item <?php echo e(request()->routeIs('settings.fnb.category') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.fnb.category')); ?>">Category FnB</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.fnb') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.fnb')); ?>">Menu FnB</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.tax') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.tax')); ?>">Tax</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="menu-item has-sub <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
                    <a href="#" class="menu-link">
                        <span><i class="bi bi-sliders"></i> Settings</span>
                    </a>
                    <div class="submenu ">
                        <div class="submenu-group-wrapper">
                            <ul class="submenu-group">
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.store') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.store')); ?>">Store</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.table') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.table')); ?>">Table</a>
                                </li>
                                <li class="submenu-item <?php echo e(request()->routeIs('settings.user') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('settings.user')); ?>">User</a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </li>
            <?php endif; ?>
            <li class="menu-item has-sub <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
                <a href="#" class="menu-link">
                    <span><i class="bi bi-sliders"></i> Reports</span>
                </a>
                <div class="submenu ">
                    <div class="submenu-group-wrapper">
                        <ul class="submenu-group">
                            <li class="submenu-item <?php echo e(request()->routeIs('reports.byitems') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('reports.byitems')); ?>">By Items</a>
                            </li>
                            <li class="submenu-item <?php echo e(request()->routeIs('reports.byshift') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('reports.byshift')); ?>">By Shift</a>
                            </li>
                            <li class="submenu-item <?php echo e(request()->routeIs('reports.byuser') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('reports.byuser')); ?>">By User</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </li>
            <li class="menu-item">
                <div class="menu-link d-flex align-items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        aria-hidden="true" role="img" class="iconify iconify--system-uicons" width="20"
                        height="20" preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round"
                            stroke-linejoin="round">
                            <path
                                d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2"
                                opacity=".3"></path>
                            <g transform="translate(-210 -1)">
                                <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                                <circle cx="220.5" cy="11.5" r="4"></circle>
                                <path d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                                </path>
                            </g>
                        </g>
                    </svg>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="toggle-dark" style="cursor: pointer">
                        <label class="form-check-label" for="toggle-dark"></label>
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                        aria-hidden="true" role="img" class="iconify iconify--mdi" width="20" height="20"
                        preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                        <path fill="currentColor"
                            d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                        </path>
                    </svg>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /home/billiar89ciamis/public_html/resources/views/components/navigation.blade.php ENDPATH**/ ?>