<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<!--
-- Template : Mazer - Free and Open-source Bootstrap 5 Admin Dashboard Template and Landing Page
-- Source : http://zuramai.github.io/mazer
-- Crafted by : Saugi - https://saugi.me
-->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/css/style-dark.css']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/ext/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/ext/sweetalert2/sweetalert2.min.css')); ?>">

    <script>
        const body = document.body;
        const theme = localStorage.getItem('theme')

        if (theme)
            document.documentElement.setAttribute('data-bs-theme', theme)
    </script>

    <?php echo $__env->yieldContent('script_tag'); ?>
</head>

<body>

    <div id="app">
        <div id="main" class="layout-horizontal">
            <header class="mb-5">
                <div class="header-top">
                    <div class="container">
                        <div class="logo">
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="logo" style="height: 50px">
                                
                            </a>
                        </div>
                        <div class="header-top-right">
                            <?php if(!empty($shift)): ?>
                                <div>
                                    <button class="btn btn-outline-danger" id="btnCloseShift"
                                        data-id="<?php echo e($shift->id_user_shift); ?>">Close Shift</button>
                                </div>
                            <?php else: ?>
                                <div>
                                    <button class="btn btn-outline-primary" id="btnOpenShift">Open Shift</button>
                                </div>
                            <?php endif; ?>
                            <div class="dropdown">
                                <a href="#" id="topbarUserDropdown"
                                    class="user-dropdown d-flex align-items-center dropend dropdown-toggle "
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="p-0 me-2">
                                        <i class="bi bi-person-circle fs-2"></i>
                                    </div>
                                    <div class="text">
                                        <h6 class="user-dropdown-name"><?php echo e(Auth::user()->name); ?></h6>
                                        <p class="user-dropdown-status text-sm text-muted"><?php echo e(Auth::user()->role); ?></p>
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end shadow-lg"
                                    aria-labelledby="topbarUserDropdown">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i
                                                class="bi bi-person-gear"></i> Profile</a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li>
                                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                                                                this.closest('form').submit();">
                                                <i class="bi bi-box-arrow-right"></i>
                                                <?php echo e(__('Log Out')); ?>

                                            </a>
                                        </form>
                                    </li>
                                </ul>
                            </div>

                            <!-- Burger button responsive -->
                            <a href="#" class="burger-btn d-block d-xl-none">
                                <i class="bi bi-justify fs-3"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <?php if (isset($component)) { $__componentOriginalf75d29720390c8e1fa3307604849a543 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf75d29720390c8e1fa3307604849a543 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf75d29720390c8e1fa3307604849a543)): ?>
<?php $attributes = $__attributesOriginalf75d29720390c8e1fa3307604849a543; ?>
<?php unset($__attributesOriginalf75d29720390c8e1fa3307604849a543); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf75d29720390c8e1fa3307604849a543)): ?>
<?php $component = $__componentOriginalf75d29720390c8e1fa3307604849a543; ?>
<?php unset($__componentOriginalf75d29720390c8e1fa3307604849a543); ?>
<?php endif; ?>

            </header>

            <div class="content-wrapper container">

                <div class="page-heading">
                    <h3><?php echo $__env->yieldContent('title'); ?></h3>
                </div>
                <div class="page-content">
                    <section class="row">
                        <div class="col-12">
                            <?php if(empty($shift)): ?>
                                
                                <div class="alert alert-warning">Reminder: You haven't opened your shift yet.
                                    Please do so to proceed with your tasks. Thank you!</div>
                                
                            <?php endif; ?>

                            <?php echo $__env->yieldContent('content'); ?>

                        </div>
                    </section>
                </div>

            </div>
        </div>
    </div>

    
    <div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" id="modalAddShift"
        aria-labelledby="modalAddShiftLabel">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalAddShiftLabel">Open Shift</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-0">
                    <form action="#" id="formAddShift">
                        <?php echo csrf_field(); ?>
                        <div class="mt-3 mb-3">
                            <label for="initial_capital" class="form-label">Initial Capital</label>
                            <input type="number" name="initial_capital" id="initial_capital" class="form-control"
                                required>
                        </div>
                        <div class="mb-3">
                            <label for="information" class="form-label">Shift Information (Optional)</label>
                            <textarea name="information" id="information" class="form-control"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" form="formAddShift" id="submitAddShift">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" id="modalCloseShift"
        aria-labelledby="modalCloseShiftLabel">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalCloseShiftLabel">Close Shift</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-0">
                    <form action="#" id="formCloseShift">
                        <?php echo csrf_field(); ?>
                        <div class="mt-3 mb-3">
                            <label for="actual_cash" class="form-label">Actual Cash*</label>
                            <input type="number" name="actual_cash" id="actual_cash" class="form-control" required>
                        </div>
                        <div class="mt-3 mb-3">
                            <label for="cash_out" class="form-label">Cash Out*</label>
                            <input type="number" name="cash_out" id="cash_out" class="form-control"
                                value="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="cash_out_info" class="form-label">Cash Out Info (Required if cash out is
                                any)</label>
                            <textarea name="cash_out_info" id="cash_out_info" class="form-control"></textarea>
                        </div>
                        <input type="hidden" name="id_shift" id="id_shift" value="">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" form="formCloseShift" id="submitCloseShift">
                        Close Shift
                    </button>
                </div>
            </div>
        </div>
    </div>
    

    <script src="<?php echo e(asset('assets/ext/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/ext/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/ext/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dark.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/horizontal-layout.js')); ?>"></script>


    <?php echo $__env->yieldContent('script'); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/shift.js'); ?>
</body>

</html>
<?php /**PATH /home/billiar89ciamis/public_html/resources/views/layouts/main.blade.php ENDPATH**/ ?>